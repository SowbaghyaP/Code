package com.user.login.loginuser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.user.login.loginuser.repo.LoginRepository;
import com.user.login.loginuser.userdetails.Login;
import com.user.login.loginuser.userdetails.SignUp;
import com.user.login.loginuser.userdetails.UserJPARepositaory;
import com.user.login.loginuser.userdetails.Users;

@RestController
@RequestMapping("/api")
public class LoginController {

	@Autowired
	private LoginRepository repository;

	@Autowired
	Validation validation;

	@PostMapping("/signUp")
	public ResponseEntity<Object> signUpUser(@RequestBody SignUp signup) {

		
		if (validation.validateUser(signup)) 
		{
			
			return new ResponseEntity<>("Fill the mandatory fields", HttpStatus.BAD_REQUEST);
		}

		if (repository.existsByUserName(signup.getUsername())) {
			return ResponseEntity.badRequest().body("Error: Username is already taken!");
		}

		if (repository.existsByEmail(signup.getEmail())) {
			return ResponseEntity.badRequest().body("Error: Email is already in use!");
		}
		
		Users user = new Users();
		user.setUserName(signup.getUsername());
		user.setEmail(signup.getEmail());
		user.setPassword(signup.getPassword());
		user.setPhoneNo(signup.getPhoneNo());
		user.setState(signup.getState());
		repository.save(user);

		return new ResponseEntity<>("User registered", HttpStatus.CREATED);
	}

	@PostMapping("/login")
	public ResponseEntity<Object> loginUser(@RequestBody Login login) {

		if (validation.validateLoginUser(login)) 
		{
			
			return new ResponseEntity<>("Fill the mandatory fields", HttpStatus.BAD_REQUEST);
		}

		Users user = repository.findByUserNameAndPassword(login.getUserName(), login.getPassword());

		if (user != null) {
			return new ResponseEntity<>("User login", HttpStatus.OK);

		}
		return new ResponseEntity<>("User not registered", HttpStatus.CONFLICT);
	}
}